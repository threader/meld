#ifndef _PYCAIRO_CMODULELIB_H_
#define _PYCAIRO_CMODULELIB_H_

PyObject *create_image_surface (PyObject *self, PyObject *args);

#endif
