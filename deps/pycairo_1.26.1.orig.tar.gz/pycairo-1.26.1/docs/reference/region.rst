.. _region:

******
Region
******
Region — Representing a pixel-aligned area

.. currentmodule:: cairo

class Region()
==============

.. autoclass:: Region
    :members:
    :undoc-members:

    .. automethod:: __init__

class RectangleInt()
====================

.. autoclass:: cairo.RectangleInt
    :members:
    :undoc-members:

    .. automethod:: __init__