.. _textcluster:

************
Text Cluster
************

.. currentmodule:: cairo

class TextCluster(tuple)
========================

.. autoclass:: TextCluster
    :members:
    :undoc-members:

    .. automethod:: __init__